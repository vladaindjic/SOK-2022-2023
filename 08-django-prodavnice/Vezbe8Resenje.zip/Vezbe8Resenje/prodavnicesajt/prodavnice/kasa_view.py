from django.apps.registry import apps
from django.shortcuts import render, redirect

from .util import convert_to_boolean
from .models import Kasa, Prodavnica


def lista_kasa(request):
    title = apps.get_app_config('prodavnice').verbose_name
    kase=Kasa.objects.all()
    return render(request, "lista_kasa.html",{"title":title,"kase":kase})

def unos_kase(request,id=None):
    title = apps.get_app_config('prodavnice').verbose_name
    if request.method=='GET':
        prodavnice=Prodavnica.objects.all()
        greska_kase = None
        if not prodavnice.exists():
            greska_kase = "Da biste mogli da unosite Kase morate uneti bar jednu prodavnicu."

        if greska_kase:
            return render(request, "unos_kase.html",
                          {"title": title, "greska_kase": greska_kase})
        if id is None:
            return render(request,"unos_kase.html",{"title":title,"prodavnice":prodavnice})
        else:
            k=Kasa.objects.get(id=id)
            return render(request,"unos_kase.html",{"title":title,"stari_id":id,"oznaka":k.oznaka,
                                                    "naziv":k.naziv,"radi":k.radi,
                                                    "prodavnica":k.prodavnica,"prodavnice":prodavnice})
    else:
        greska_oznaka=None
        greska_naziv=None
        greska_radi = None
        greska_prodavnica = None
        oznaka = request.POST['oznaka']
        naziv = request.POST['naziv']
        try:
            radi, radi_converted = convert_to_boolean(request.POST['radi'])
        except:
            radi=False
        prodavnica = request.POST['prodavnica']


        try:
            stari_id = request.POST['stari_id']
        except:
            stari_id = None

        if oznaka is not None and oznaka =="":
            greska_oznaka="Morate uneti oznaku"
        if naziv is not None and naziv == "":
            greska_naziv="Morate uneti naziv"
        if radi is not None and radi == "":
            greska_radi="Morate odrediti da li radi"

        if prodavnica is not None and prodavnica == "":
            greska_prodavnica="Morate izabrati prodavnicu"


        if greska_prodavnica is None:
            p = Prodavnica.objects.get(id=prodavnica)
            if p is not None:
                prodavnica = p
            else:
                greska_prodavnica = "Izabrana prodavnica ne postoji"

        if greska_oznaka is None:
            try:
                k = Kasa.objects.get(oznaka=oznaka)
                if stari_id is not None:
                    k2 = Kasa.objects.get(id=stari_id)
                    if k2.oznaka != k.oznaka:
                        greska_oznaka = "Kasa sa tom vrednoscu oznake vec postoji"
                else:
                    greska_oznaka = "Kasa sa tom vrednoscu oznake vec postoji"
            except:
                pass

        if greska_oznaka is None and greska_naziv is None and greska_radi is None and greska_prodavnica is None:
            if stari_id is None:
                k=Kasa(oznaka=oznaka,naziv=naziv,radi=radi,prodavnica=prodavnica)
                k.save()
            else:
                k = Kasa.objects.get(id=stari_id)
                k.oznaka=oznaka
                k.naziv=naziv
                k.radi=radi
                k.prodavnica=prodavnica
                k.save()
            return redirect('lista_kasa')
        prodavnice=Prodavnica.objects.all()
        return render(request,"unos_kase.html",{"title":title,"greska_oznaka":greska_oznaka,
                                   "greska_naziv":greska_naziv,"greska_rado":greska_radi,
                                   "greska_prodavnica":greska_prodavnica,
                                   "oznaka":oznaka,"naziv":naziv,"radi":radi,
                                   "stari_id":stari_id,
                                   "prodavnica":prodavnica,
                                   "prodavnice":prodavnice}
                                   )
