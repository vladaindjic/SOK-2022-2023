import pkg_resources

def console_menu(*args,**kwargs):
    svi_plugini=[]
    napravi_opcije(svi_plugini=svi_plugini,*args,**kwargs)
    if len(svi_plugini)==0:
        print("Nije prepoznati nijedan plugin!")
        return
    greska=False
    poruka=None
    while True:
        print("-----------------------------------")
        if greska:
            print("Uneli ste pogresnu vrednost za opciju")
            greska=False
        if poruka:
            print(poruka)
        print("Izaberite broj opcije:")
        for i,opcija in enumerate(svi_plugini):
            print("{} {} {}".format(i,opcija.identifier(),opcija.name()))
        print("{} za izlaz".format(len(svi_plugini)))
        try:
            izbor = int(input("Unesite redni broj opcije:"))
        except:
            greska=True
            continue
        if izbor == len(svi_plugini):
            return
        elif 0 <= izbor < len(svi_plugini):
            poruka=izabrana_opcija(opcija=svi_plugini[izbor],*args,**kwargs)
        else:
            greska=True


def izabrana_opcija(*args,**kwargs):
    try:
        opcija=kwargs['opcija']
        try:
            fakulteti=kwargs['fakulteti']
            pomocna_lista=opcija.ucitati_fakultete()
            del fakulteti[:]
            fakulteti.extend(pomocna_lista)
            return "Ucitani fakulteti"
        except AttributeError as ea:
            pass
        except Exception as e:
            print("Error: {}".format(e))

        try:
            fakulteti=kwargs['fakulteti']
            return opcija.prikazati_fakultete(fakulteti)
        except AttributeError as ea:
            pass
        except Exception as e:
            print("Error: {}".format(e))

        try:
            fakulteti = kwargs['fakulteti']
            studenti=kwargs['studenti']
            pomocna_lista=opcija.ucitati_studente(fakulteti)
            del studenti[:]
            studenti.extend(pomocna_lista)
            return "Ucitani studenti"
        except AttributeError as ea:
            pass
        except Exception as e:
            print("Error: {}".format(e))

        try:
            studenti=kwargs['studenti']
            return opcija.prikazati_studente(studenti)
        except AttributeError as ea:
            pass
        except Exception as e:
            print("Error: {}".format(e))
    except:
        pass


def napravi_opcije(*args,**kwargs):
    try:
        svi_plugini=kwargs['svi_plugini']
        try:
            svi_plugini.extend(kwargs['fakultet_ucitavanje'])
        except Exception as e:
            pass
        try:
            svi_plugini.extend(kwargs['fakultet_prikaz'])
        except Exception as e:
            pass
        try:
            svi_plugini.extend(kwargs['student_ucitavanje'])
        except Exception as e:
            pass
        try:
            svi_plugini.extend(kwargs['student_prikaz'])
        except Exception as e:
            pass
    except:
        pass


def load_plugins(oznaka):
    plugins = []
    for ep in pkg_resources.iter_entry_points(group=oznaka):
        p = ep.load()
        print("{} {}".format(ep.name, p))
        plugin = p()
        plugins.append(plugin)
    return plugins


def main():
    try:
        fakultet_ucitavanje = load_plugins("fakultet.ucitavanje")
        fakultet_prikaz = load_plugins("fakultet.prikaz")
        student_ucitavanje = load_plugins("student.ucitati")
        student_prikaz = load_plugins("student.prikaz")

    except Exception as e:
            print("Error: {}".format(e))

            return

    try:
        fakulteti=[]
        studenti=[]
        console_menu(fakultet_ucitavanje=fakultet_ucitavanje,
             fakultet_prikaz=fakultet_prikaz,
             student_ucitavanje=student_ucitavanje,
             student_prikaz=student_prikaz,
             fakulteti=fakulteti,
             studenti=studenti)

    except Exception as e:
        print("Error: {}".format(e))
        return

if __name__ == '__main__':
    main()