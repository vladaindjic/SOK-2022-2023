from rs.uns.ftn.studentska.sluzba.model import Student
from rs.uns.ftn.studentska.sluzba.services.student import StudentUcitatiBase


class StudentiUcitavanjeKod(StudentUcitatiBase):
    def identifier(self):
        return "StudentiUcitavanjeKod"
    def name(self):
        return "Ucitavanje studenata u kodu"
    def ucitati_studente(self, lista_fakulteta):
        studenti=[]
        studenti.append(
            Student(indeks="E12345",
                    ime="Neda",
                    prezime="Nedic",
                    email="email1@gmail.com",
                    fakultet=lista_fakulteta[0]))
        studenti.append(
            Student(indeks="H4578",
                    ime="Petar",
                    prezime="Petrovic",
                    email="email1@gmail.com",
                    fakultet=lista_fakulteta[1])
        )
        return studenti