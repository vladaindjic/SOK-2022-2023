from setuptools import setup, find_packages
setup(
    name="ucitavanje-studenti-kod",
    version="0.1",
    packages=find_packages(),
    namespace_packages=['rs','rs.uns','rs.uns.ftn','rs.uns.ftn.studenti'],
    entry_points = {
        'student.ucitati':
            ['ucitavanje_kod=rs.uns.ftn.studenti.ucitavanje_kod:StudentiUcitavanjeKod'],
    },
    zip_safe=True
)