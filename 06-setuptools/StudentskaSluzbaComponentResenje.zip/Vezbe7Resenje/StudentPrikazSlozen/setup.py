from setuptools import setup, find_packages
setup(
    name="prikaz-student-slozen",
    version="0.1",
    packages=find_packages(),
    namespace_packages=['rs','rs.uns','rs.uns.ftn','rs.uns.ftn.studenti'],
    entry_points = {
        'student.prikaz':
            ['prikaz_slozen=rs.uns.ftn.studenti.prikaz_slozen:StudentiPrikazSlozen'],
    },
    zip_safe=True
)