import os

from rs.uns.ftn.studentska.sluzba.model import Student
from rs.uns.ftn.studentska.sluzba.services.student import StudentUcitatiBase


def apsolutnaPutanja(fajl):
    return os.path.join(os.path.dirname(__file__),"..","..","..","..","fajlovi",fajl)

studentiTxt=apsolutnaPutanja("studenti.txt")

def ucitatiStudente(fajl,lista_fakulteta):
    studenti=[]
    with open(fajl,"r") as f:
        for line in f.readlines():
            atributi=line.split("|")
            s=Student()
            s.indeks = atributi[0]
            s.ime = atributi[1]
            s.prezime = atributi[2]
            s.email = atributi[3]
            for f in lista_fakulteta:
                if atributi[4] == f.oznaka:
                    s.fakultet = f
            studenti.append(s)
    return studenti

class StudentiUcitavanjeFajl(StudentUcitatiBase):
    def identifier(self):
        return "StudentiUcitavanjeFajl"
    def name(self):
        return "Ucitavanje studenata iz fajla"
    def ucitati_studente(self, lista_fakulteta):
        return ucitatiStudente(studentiTxt,lista_fakulteta)