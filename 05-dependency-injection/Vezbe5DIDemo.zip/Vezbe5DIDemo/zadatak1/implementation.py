from zadatak1.abstract_types import AbstractHero, FightResult, AbstractVehicle


class Batman(AbstractHero):
    def fight_crime(self):
        print("Batman is fighting against crime!")

    def fight_hero(self, other_hero):
        return FightResult.WIN


class Batmobil(AbstractVehicle):
    def drive_car(self):
        print("Car with name {},"
              " with max speed {} is driven!"
              .format(self.name, self.speed))


class Frogman(AbstractHero):
    def fight_crime(self):
        print("Frogman is fighting against crime!")

    def fight_hero(self, other_hero):
        return FightResult.WIN


class Frogmobil(AbstractVehicle):
    def drive_car(self):
        print("Car with name {},"
              " with max speed {} is driven!"
              .format(self.name, self.speed))


class Hulk(AbstractHero):
    def fight_crime(self):
        print("Hulk is fighting against crime!")

    def fight_hero(self, other_hero):
        return FightResult.WIN


class IronMan(AbstractHero):
    def fight_crime(self):
        print("IronMan is fighting against crime!")

    def fight_hero(self, other_hero):
        return FightResult.WIN