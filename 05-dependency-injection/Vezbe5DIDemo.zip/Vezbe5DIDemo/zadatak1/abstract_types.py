from abc import ABC, abstractmethod
from enum import Enum


class AbstractHero(ABC):
    def __init__(self, health, name, vehicle):
        self.health = health
        self.name = name
        self.vehicle = vehicle
    @abstractmethod
    def fight_crime(self):
        pass

    @abstractmethod
    def fight_hero(self, other_hero):
        pass

    def __str__(self):
        return "Hero{{health {} name {} vehicle {}}}"\
                 .format(self.health,self.name,
                         self.vehicle)


class AbstractVehicle(ABC):
    def __init__(self, speed, name):
        self.speed = speed
        self.name = name

    @abstractmethod
    def drive_car(self):
        pass

    def __str__(self):
        return "Vehicle{{speed {} name {}}}"\
                 .format(self.speed,self.name)


class FightResult(Enum):
    WIN = 0
    LOSE = 1