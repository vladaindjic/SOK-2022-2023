from zadatak2.abstract_types import EditField, Button, Label


class GnomeLabel(Label):
    def draw(self):
        print("Gnome Label")

class MacOSLabel(Label):
    def draw(self):
        print("MacOS Label")

class WindowsLabel(Label):
    def draw(self):
        print("Windows Label")

class GnomeButton(Button):
    def draw(self):
        print("Gnome Button")

class MacOSButton(Button):
    def draw(self):
        print("MacOS Button")

class WindowsButton(Button):
    def draw(self):
        print("Windows Button")

class GnomeEditField(EditField):
    def draw(self):
        print("Gnome EditField")

class MacOSEditField(EditField):
    def draw(self):
        print("MacOS EditField")

class WindowsEditField(EditField):
    def draw(self):
        print("Windows EditField")