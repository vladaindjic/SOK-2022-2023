from zadatak2.abstract.factory.abstract_types import Creator
from zadatak2.implementation import GnomeLabel, GnomeButton, GnomeEditField, MacOSLabel, MacOSButton, MacOSEditField, \
    WindowsLabel, WindowsButton, WindowsEditField


class GnomeCreator(Creator):
    def createLabel(self):
        return GnomeLabel()
    def createButton(self):
        return GnomeButton()
    def createEditField(self):
        return GnomeEditField()

class MacOSCreator(Creator):
    def createLabel(self):
        return MacOSLabel()
    def createButton(self):
        return MacOSButton()
    def createEditField(self):
        return MacOSEditField()

class WindowsCreator(Creator):
    def createLabel(self):
        return WindowsLabel()
    def createButton(self):
        return WindowsButton()
    def createEditField(self):
        return WindowsEditField()