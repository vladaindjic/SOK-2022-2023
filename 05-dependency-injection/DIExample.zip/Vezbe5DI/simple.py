from injector import inject, Module, provider


# for more information, see the documentation: https://injector.readthedocs.io/en/latest/index.html
# terminology can be found here: https://injector.readthedocs.io/en/latest/terminology.html
# for type hints, see this: https://docs.python.org/3/library/typing.html
#   Note that python is still dynamically type programming languages.

class Name:
    pass


class Description:
    pass


class User:
    @inject
    def __init__(self, name: Name, description: Description):
        """
        User needs a reference to instances of Name and Description types.

        Both name and description attributes are string, but for the sake of
        injection, they are defined as custom types (classes).
        """
        self.name = name
        self.description = description

    def __str__(self):
        return "name: %s, description: %s" % (self.name, self.description)


class UserModule(Module):
    """
    A Module configures bindings. It provides methods that simplify the process of binding a key to a provider.
    """

    def configure(self, binder):
        """
        Binder is responsible to bind the type to its Instance
        """
        binder.bind(User)


class UserAttributeModule(Module):
    def configure(self, binder):
        """
        Bind type Name to a string used as a user name.
        """
        binder.bind(Name, to='Sherlock')

    @provider
    def describe(self, name: Name) -> Description:
        """
        If the logic for binding is a bit more complex, it is possible to
        define the provider methods.
        """
        return '%s is a man of astounding insight' % name


if __name__ == '__main__':
    from injector import Injector

    # Create injector instance by using two modules
    injector = Injector([UserModule, UserAttributeModule])
    # Injector is now ready to provide an instance of a User class
    print(injector.get(User))
