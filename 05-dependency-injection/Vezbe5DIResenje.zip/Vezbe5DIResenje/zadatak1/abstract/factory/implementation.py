from zadatak1.abstract.factory.abstract_types import AbstractStory, StoryCreator
from zadatak1.implementation import Batman, Batmobil, Frogman, Frogmobil


class HeroVehicleStory(AbstractStory):
    def __init__(self,creator):
        self.hero=creator.createHero()
        self.vehicle=creator.createVehicle()

    def tell_story(self):
        print("Story of {}".format(self.hero.name))
        self.hero.fight_crime()
        self.vehicle.drive_car()

class BatmanBatmobilCreator(StoryCreator):
    def createHero(self):
        return Batman(100,"Batman",self.createVehicle())

    def createVehicle(self):
        return Batmobil(300,"Batmobil")

class FrogmanFrogmobilCreator(StoryCreator):
    def createHero(self):
        return Frogman(100,"Frogman",self.createVehicle())

    def createVehicle(self):
        return Frogmobil(200,"Frogmobil")