from zadatak1.abstract.factory.implementation import HeroVehicleStory, BatmanBatmobilCreator, FrogmanFrogmobilCreator

if __name__ == '__main__':
    b=HeroVehicleStory(BatmanBatmobilCreator())
    b.tell_story()

    f=HeroVehicleStory(FrogmanFrogmobilCreator())
    f.tell_story()