from abc import ABC, abstractmethod


class AbstractStory(ABC):
    @abstractmethod
    def tell_story(self):
        pass

class StoryCreator(ABC):
    @abstractmethod
    def createHero(self):
        pass
    @abstractmethod
    def createVehicle(self):
        pass