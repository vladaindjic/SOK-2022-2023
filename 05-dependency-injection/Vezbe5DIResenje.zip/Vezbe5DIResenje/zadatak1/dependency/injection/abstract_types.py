from abc import ABC, abstractmethod


class AbstractStory(ABC):
    @abstractmethod
    def tell_story(self):
        pass