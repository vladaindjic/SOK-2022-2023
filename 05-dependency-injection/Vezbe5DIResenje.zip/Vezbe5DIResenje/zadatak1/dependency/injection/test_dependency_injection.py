from injector import Injector

from zadatak1.dependency.injection.abstract_types import AbstractStory
from zadatak1.dependency.injection.injector_modules import BatmanBatmobilModule, FrogmanFrogmobilModule, \
    BatmanValuesModule, FrogmanValuesModule


def story1():
    injector=Injector([BatmanBatmobilModule,BatmanValuesModule])
    return injector.get(AbstractStory)

def story2():
    injector=Injector([FrogmanFrogmobilModule,FrogmanValuesModule])
    return injector.get(AbstractStory)

if __name__ == '__main__':
    bs=story1()
    bs.tell_story()

    bs=story2()
    bs.tell_story()