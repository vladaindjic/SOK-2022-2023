from injector import inject

from zadatak1.abstract.factory.abstract_types import AbstractStory, StoryCreator
from zadatak1.abstract_types import AbstractHero, AbstractVehicle


class HeroVehicleStory(AbstractStory):
    @inject
    def __init__(self,hero:AbstractHero,vehicle:AbstractVehicle):
        self.hero=hero
        self.vehicle=vehicle

    def tell_story(self):
        print("Story of {}".format(self.hero.name))
        self.hero.fight_crime()
        self.vehicle.drive_car()