from injector import Module, provider, singleton, Key

from zadatak1.abstract_types import AbstractVehicle, AbstractHero
from zadatak1.dependency.injection.abstract_types import AbstractStory
from zadatak1.dependency.injection.implementation import HeroVehicleStory
from zadatak1.implementation import Batman, Batmobil, Frogman, Frogmobil

class HeroName:
    pass
class HeroHealth:
    pass
class VehicleName:
    pass
class VehicleSpeed:
    pass


class BatmanBatmobilModule(Module):
    def configure(self, binder):
        binder.bind(AbstractStory,to=HeroVehicleStory)

    @singleton
    @provider
    def provideHero(self,name:HeroName, health:HeroHealth, vehicle:AbstractVehicle)\
        ->AbstractHero:
        return Batman(health,name,vehicle)

    @provider
    def provideVehicle(self,speed:VehicleSpeed,name:VehicleName)->AbstractVehicle:
        return Batmobil(speed,name)


class BatmanValuesModule(Module):
    def configure(self, binder):
        binder.bind(HeroName,to="Batman")
        binder.bind(HeroHealth, to=100)
        binder.bind(VehicleName, to="Batmobil")
        binder.bind(VehicleSpeed, to=300)

class FrogmanFrogmobilModule(Module):
    def configure(self, binder):
        binder.bind(AbstractStory,to=HeroVehicleStory)

    @singleton
    @provider
    def provideHero(self,name:HeroName, health:HeroHealth, vehicle:AbstractVehicle)\
        ->AbstractHero:
        return Frogman(health,name,vehicle)

    @provider
    def provideVehicle(self,speed:VehicleSpeed,name:VehicleName)->AbstractVehicle:
        return Frogmobil(speed,name)

class FrogmanValuesModule(Module):
    def configure(self, binder):
        binder.bind(HeroName,to="Frogman")
        binder.bind(HeroHealth, to=100)
        binder.bind(VehicleName, to="Frogmobil")
        binder.bind(VehicleSpeed, to=200)