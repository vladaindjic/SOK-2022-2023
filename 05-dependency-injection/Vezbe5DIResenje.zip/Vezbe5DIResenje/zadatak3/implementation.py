from zadatak3.abstract_types import ICreditCardProcessor, ITransactionLog, IBillingService, ICreditCard


class PayPalCreditCardProcessor(ICreditCardProcessor):
    def charge(self, card, amount):
        print("Pay pal charging: {} from credit card: {}".format(amount,card))
        return ChargeResult(True)


class MachineCreditCardProcessor(ICreditCardProcessor):
    def charge(self, card, amount):
        print("Machine charging: {} from credit card: {}".format(amount,card))
        return ChargeResult(True)


class DatabaseTransactionLog(ITransactionLog):
    def log_charge_result(self,result):
        print("Database log: {}".format(result))

    def log_connect_exception(self,e):
        print("Database log exception: {}".format(e))


class FileTransactionLog(ITransactionLog):
    def log_charge_result(self,result):
        print("File log: {}".format(result))

    def log_connect_exception(self,e):
        print("File log exception: {}".format(e))


class ChargeResult(object):
    def __init__(self, successful):
        self.successful=successful

    def was_successful(self):
        return self.successful

    def __str__(self):
        if self.successful:
            return "Successful charge"
        else:
            return "Unsuccessful charge"


class RealBillingService(IBillingService):
    def charge_order(self, order, credit_card):
        try:
            result=self.processor.charge(credit_card,order.amount)
            self.transaction_log.log_charge_result(result)
        except Exception as e:
            self.transaction_log.log_connect_exception(e)


class VisaCreditCard(ICreditCard):
    def __str__(self):
        return "Visa credit card"


class MasterCreditCard(ICreditCard):
    def __str__(self):
        return "Master credit card"


class PizzaOrder(object):
    def __init__(self,amount):
        self.amount=amount
