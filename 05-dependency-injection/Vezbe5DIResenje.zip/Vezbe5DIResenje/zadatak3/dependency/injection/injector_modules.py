from injector import Module, Key

from zadatak3.abstract_types import Shop, IBillingService, ITransactionLog, ICreditCardProcessor
from zadatak3.implementation import RealBillingService, DatabaseTransactionLog, PayPalCreditCardProcessor, \
    FileTransactionLog, MachineCreditCardProcessor

class OnlineShop:
    pass
class Market:
    pass


class OnlineShopModules(Module):
    def configure(self, binder):
        binder.bind(OnlineShop,to=Shop)
        binder.bind(IBillingService,to=RealBillingService)
        binder.bind(ITransactionLog,to=DatabaseTransactionLog)
        binder.bind(ICreditCardProcessor, to=PayPalCreditCardProcessor)


class MarketShopModules(Module):
    def configure(self, binder):
        binder.bind(Market, to=Shop)
        binder.bind(IBillingService, to=RealBillingService)
        binder.bind(ITransactionLog, to=FileTransactionLog)
        binder.bind(ICreditCardProcessor, to=MachineCreditCardProcessor)