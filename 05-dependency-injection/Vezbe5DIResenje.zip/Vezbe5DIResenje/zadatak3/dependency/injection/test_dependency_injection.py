from injector import Injector

from zadatak3.dependency.injection.injector_modules import OnlineShopModules, OnlineShop, MarketShopModules, Market
from zadatak3.implementation import PizzaOrder, VisaCreditCard, MasterCreditCard

if __name__ == '__main__':
    b=Injector([OnlineShopModules])
    shop=b.get(OnlineShop)
    shop.billing_service.charge_order(PizzaOrder(23),VisaCreditCard())

    b = Injector([MarketShopModules])
    shop = b.get(Market)
    shop.billing_service.charge_order(PizzaOrder(23), MasterCreditCard())