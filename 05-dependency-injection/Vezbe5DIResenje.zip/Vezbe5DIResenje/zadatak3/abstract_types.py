from abc import ABC, abstractmethod

from injector import inject


class ICreditCardProcessor(ABC):
    @abstractmethod
    def charge(self, card, amount):
        pass


class ICreditCard(ABC):
    pass


class ITransactionLog(ABC):
    @abstractmethod
    def log_charge_result(self,result):
        pass

    @abstractmethod
    def log_connect_exception(self,e):
        pass


class IBillingService(ABC):
    @inject
    def __init__(self,transaction_log:ITransactionLog,
                 processor:ICreditCardProcessor):
        self.transaction_log=transaction_log
        self.processor=processor

    @abstractmethod
    def charge_order(self, order, credit_card):
        pass


class Shop(object):
    @inject
    def __init__(self,billing_service:IBillingService):
        self.billing_service=billing_service