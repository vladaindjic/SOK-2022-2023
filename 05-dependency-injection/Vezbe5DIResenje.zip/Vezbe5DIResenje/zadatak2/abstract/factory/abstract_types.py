from abc import ABC, abstractmethod


class Creator(ABC):
    @abstractmethod
    def createLabel(self):
        pass
    @abstractmethod
    def createButton(self):
        pass
    @abstractmethod
    def createEditField(self):
        pass