from zadatak2.abstract.factory.implementation import GnomeCreator, MacOSCreator, WindowsCreator


def testProzor(creator):
    #creator=GnomeCreator()
    #creator=MacOSCreator()
    komponente=[]
    komponente.append(creator.createLabel())
    komponente.append(creator.createEditField())
    komponente.append(creator.createLabel())
    komponente.append(creator.createEditField())
    komponente.append(creator.createButton())
    komponente.append(creator.createButton())
    for el in komponente:
        el.draw()

if __name__ == '__main__':
    print("Gnome")
    testProzor(GnomeCreator())
    print("MacOS")
    testProzor(MacOSCreator())
    print("Windows")
    testProzor(WindowsCreator())