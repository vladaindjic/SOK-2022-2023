from injector import inject, Injector, Module, singleton

from zadatak2.abstract_types import Label, EditField, Button
from zadatak2.implementation import MacOSLabel, MacOSButton, MacOSEditField, WindowsLabel, WindowsButton, \
    WindowsEditField, GnomeLabel, GnomeButton, GnomeEditField


class MacOSModule(Module):
    def configure(self, binder):
        binder.bind(Label, to=MacOSLabel)
        binder.bind(Button, to=MacOSButton)
        binder.bind(EditField, to=MacOSEditField)


class WindowsModule(Module):
    def configure(self, binder):
        binder.bind(Label, to=WindowsLabel)
        binder.bind(Button, to=WindowsButton)
        binder.bind(EditField, to=WindowsEditField)


class GnomeModule(Module):
    def configure(self, binder):
        binder.bind(Label, to=GnomeLabel)
        binder.bind(Button, to=GnomeButton)
        binder.bind(EditField, to=GnomeEditField)