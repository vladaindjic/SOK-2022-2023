from injector import Injector, CallableProvider, inject, Module

from zadatak2.abstract_types import Label, EditField, Button
from zadatak2.dependency.injection.injector_modules import MacOSModule, GnomeModule, WindowsModule

class TestProzor:
    pass

class TestProzorModule(Module):
    def configure(self, binder):
        binder.bind(TestProzor, to=CallableProvider(testProzor))

@inject
def testProzor(label1:Label,label2:Label,
               edit_field1:EditField,
               edit_field2:EditField,
               button1:Button,
               button2:Button):
    #creator=GnomeCreator()
    #creator=MacOSCreator()
    komponente=[]
    komponente.append(label1)
    komponente.append(edit_field1)
    komponente.append(label2)
    komponente.append(edit_field2)
    komponente.append(button1)
    komponente.append(button2)
    for el in komponente:
        el.draw()

if __name__ == '__main__':
    print("Gnome")
    injector = Injector([GnomeModule,TestProzorModule])
    injector.get(TestProzor)

    print("MacOS")
    injector = Injector([MacOSModule,TestProzorModule])
    injector.get(TestProzor)

    print("Windows")
    injector = Injector([WindowsModule,TestProzorModule])
    injector.get(TestProzor)