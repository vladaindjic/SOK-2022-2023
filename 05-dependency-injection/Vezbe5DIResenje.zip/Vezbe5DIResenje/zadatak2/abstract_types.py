from abc import ABC, abstractmethod


class Product(ABC):
    @abstractmethod
    def draw(self):
        pass


class Label(Product):
    @abstractmethod
    def draw(self):
        pass


class Button(Product):
    @abstractmethod
    def draw(self):
        pass


class EditField(Product):
    @abstractmethod
    def draw(self):
        pass